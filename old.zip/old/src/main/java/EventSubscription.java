import java.time.LocalDateTime;

/**
 * Represents an event subscription
 *
 * Note: currently only includes the parameters needed for requests
 */
public class EventSubscription {
    public int id;
    public String user_id;
    public String description;
    public String filter;
    public String queue_name;
    public String exchange_name;
    public String binding_key;
    public String message_broker_hostname;
    public int message_broker_port;
    public boolean requires_secure_connection;
    public boolean is_durable;
    public boolean is_modifySub;
    public LocalDateTime created_date;
    public LocalDateTime last_updated_date;
}

import com.google.api.client.http.HttpTransport;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;
import java.util.Scanner;

public class Program {
	// OpenAccess connection details
	// Change 'localhost' to the fully qualified domain name where the OpenAccess
	// service is hosted
	static final String OPENACCESS_URL = "https://localhost:8080/api/access/onguard/openaccess/";
	static final String WEB_EVENT_BRIDGE_URL = OPENACCESS_URL + "eventbridge/";
	static final String OPENACCESS_APPLICATION_ID = "OPEN_ACCESS_NON_PRODUCTION";
	static final String OPENACCESS_USERNAME = "sa";
	static final String OPENACCESS_PASSWORD = "sa";
	static final String OPENACCESS_DIRECTORY_ID = "id-1";

	// Subscription details
	static final String SUBSCRIPTION_DESCRIPTION = "Sample Event Subscription (Java)";
	static final String SUBSCRIPTION_FILTER = "";
	static final boolean SUBSCRIPTION_IS_DURABLE = false;

	static Scanner inputScanner;

	public static void main(String[] args) throws Exception {
		// Uncomment to enable HTTP transport logging for the Google HTTP Client Library
		// enableLogging();

		//Uncomment below three lines to do modify subscription 
		boolean modify_Sub = false;
    	String eventSubName = SUBSCRIPTION_DESCRIPTION;
    	int EventSubId = 0;
    	
		inputScanner = new Scanner(System.in);
		
		// The below lines can be uncommented to do a modify subcription for user inputs
        //inputScanner = new Scanner(System.in);
       // System.out.println("Provide a subscription name");
       // eventSubName = inputScanner.nextLine();
        
       // System.out.println("is it modifysubscription");      
      //  modify_Sub = inputScanner.nextBoolean();
        
       // if(modify_Sub == true)
       // {
       // 	System.out.println("Subscription ID");
        //	EventSubId = inputScanner.nextInt();
       // }
		
		try {
			System.out.format("Connecting to the OpenAccess service at %s with application id %s...%n", OPENACCESS_URL,
					OPENACCESS_APPLICATION_ID);

			OpenAccessService service = new OpenAccessService(OPENACCESS_URL, OPENACCESS_APPLICATION_ID);
			String sessionToken = service.login(OPENACCESS_USERNAME, OPENACCESS_PASSWORD, OPENACCESS_DIRECTORY_ID);

			System.out.println("Successfully connected to the OpenAccess service.");

			EventSubscription subscription = new EventSubscription();
			subscription.description = SUBSCRIPTION_DESCRIPTION;
			subscription.filter = SUBSCRIPTION_FILTER;
			subscription.is_durable = SUBSCRIPTION_IS_DURABLE;
            subscription.is_modifySub = modify_Sub;
            subscription.id = EventSubId;

			
			boolean exit = false;
			boolean reconnect = true;
			
            if (modify_Sub == true)
            {
            	System.out.println("Modify Subscription");
            	receiveEvents(WEB_EVENT_BRIDGE_URL, sessionToken, OPENACCESS_APPLICATION_ID, subscription, modify_Sub);
            	reconnect = false;
            }
            else
            {
            	System.out.println("New Subscription");
            }
				
			while (!exit) {
				
				
				if(reconnect)
				{
					receiveEvents(WEB_EVENT_BRIDGE_URL, sessionToken, OPENACCESS_APPLICATION_ID, subscription);
					reconnect =  false;
				}
				
				System.out.println("value of isConnectionNotLost " + mysubscriber.isConenctionNotLost());
				
				if ((mysubscriber.isConenctionNotLost() == false) ) {					
					reconnect = true;
				}
				
			 /*  if (inputScanner.hasNextByte())
			    {
			    	stopReceiveEvents();
			    	exit = true;
			    }*/
			
				Thread.currentThread();
				Thread.sleep(10*1000);
				System.out.println("waking from thread " + mysubscriber.isConenctionNotLost());
			}
			service.logout();
		} catch (OpenAccessException e) {
			System.out.format("Error communicating with the OpenAccess API: %s - %s%n", e.getCode(), e.getMessage());
			System.out.println("Press enter to exit...");
			inputScanner.nextLine();
		} catch (Exception e) {
			System.out.format("Error: %s%n", e);
			System.out.println("Press enter to exit...");
			inputScanner.nextLine();
		}
	}

	static WebEventSubscriber mysubscriber;

	/**
	 * Receive events until an ENTER key is input.
	 *
	 * @param bridgeUrl     the URL of the web event bridge
	 * @param sessionToken  the authenticated session token to use with the web
	 *                      event bridge
	 * @param applicationId the application id
	 * @param subscription  the details of the event subscription
	 */
	public static void receiveEvents(String bridgeUrl, String sessionToken, String applicationId,
			EventSubscription subscription) throws Exception {
		try {
			StreamOutputEventHandler consoleHandler = new StreamOutputEventHandler(System.out);

			System.out.format("Connecting to the Web Event Bridge at %s...%n", bridgeUrl);
			mysubscriber = new WebEventSubscriber(bridgeUrl, sessionToken, applicationId, subscription, consoleHandler);

			mysubscriber.startReceiving();
		} finally {
			System.out.format("Started receiving Events from  Web Event Bridge at %s...%n", bridgeUrl);
		}
	}
	
	
	/**
     * Receive events until an ENTER key is input.
     *
     * @param bridgeUrl the URL of the web event bridge
     * @param sessionToken the authenticated session token to use with the web event bridge
     * @param applicationId the application id
     * @param subscription the details of the event subscription
     */
    public static void receiveEvents(String bridgeUrl, String sessionToken, String applicationId, EventSubscription subscription, boolean modifySub) throws Exception {
        WebEventSubscriber subscriber = null;
        try {
            StreamOutputEventHandler consoleHandler = new StreamOutputEventHandler(System.out);

            System.out.format("Connecting to the Web Event Bridge at %s...%n", bridgeUrl);
            subscriber = new WebEventSubscriber(bridgeUrl, sessionToken, applicationId, subscription, consoleHandler, modifySub);

            subscriber.startReceiving();           
        }
        finally {
        	System.out.format("Started receiving Events from  Web Event Bridge at %s...%n", bridgeUrl);
        }
    }

	public static void stopReceiveEvents() {
		try {
			mysubscriber.stopReceiving();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (mysubscriber != null)
				mysubscriber.close();
		}

	}

	/**
	 * Log HTTP requests/responses from the Google HTTP Client Library.
	 */
	public static void enableLogging() {
		Logger logger = Logger.getLogger(HttpTransport.class.getName());
		logger.setLevel(Level.CONFIG);
		logger.addHandler(new Handler() {
			@Override
			public void close() {
			}

			@Override
			public void flush() {
			}

			@Override
			public void publish(LogRecord record) {
				System.out.println(record.getMessage());
			}
		});
	}
}

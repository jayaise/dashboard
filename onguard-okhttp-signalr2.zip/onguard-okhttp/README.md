# OnGuard legacy SignalR 2.x client using OkHttp

Custom Java 11+ client for **ASP.NET SignalR 2.x** long polling, not ASP.NET Core SignalR 10. This is a protocol prototype, not a verified OnGuard integration.

## Configuration

- `ONGUARD_SIGNALR_URL` = HTTPS SignalR base endpoint, usually ending `/signalr`, not `/signalr/hubs`
- `ONGUARD_TOKEN` = optional bearer token if the SignalR bridge uses bearer auth (many installations instead use cookies)
- `ONGUARD_SESSION_TOKEN`, `ONGUARD_APPLICATION_ID`, `ONGUARD_DIRECTORY_ID` = example fields; **verify the bridge's actual `CreateSubscription` contract**

Run: `mvn package` then execute `example.onguard.Main` with the Maven dependencies on the classpath.

## Limitations / production TODO

- Authentication may use cookies or other custom headers instead of Bearer. Adapt OkHttp request builder and cookie jar to the installed bridge.
- `CreateSubscription` invocation result is delivered asynchronously via `/poll`; the sample decodes it but does not wait for/verify success. Implement subscription acceptance gating before treating subscription as active.
- `StopSubscription` is not implemented; add it using `/send` before graceful shutdown and handle the completion.
- Verify protocol negotiation fields, connection start behavior, message cursors, keepalives, reconnection behavior, and SignalR version against actual server traffic.
- Long polling reconnect may miss events; use server-supported durable subscriptions, replay, event IDs, and deduplication as available.
- The event queue is bounded; choose an explicit backpressure/overflow strategy and durable persistence if events cannot be dropped.
- Configure TLS trust and certificate verification properly; never disable verification.
- Avoid printing session tokens or credentials in logs.
- Do not use unverified field names for the OnGuard `connectionInfo` and subscription structures.

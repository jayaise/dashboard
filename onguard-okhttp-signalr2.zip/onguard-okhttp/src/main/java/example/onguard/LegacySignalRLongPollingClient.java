package example.onguard;

import com.google.gson.*;
import okhttp3.*;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;

/** Minimal ASP.NET SignalR 2.x long-polling hub client; NOT ASP.NET Core SignalR. */
public final class LegacySignalRLongPollingClient implements AutoCloseable {
    private static final String PROTOCOL = "1.5";
    private static final MediaType FORM = MediaType.get("application/x-www-form-urlencoded; charset=utf-8");
    private final OkHttpClient http;
    private final HttpUrl base;
    private final String hub;
    private final String connectionData;
    private final String authHeader;
    private final BlockingQueue<JsonObject> events = new LinkedBlockingQueue<>(10000);
    private final Map<String, Consumer<JsonArray>> handlers = new ConcurrentHashMap<>();
    private final AtomicBoolean running = new AtomicBoolean(false);
    private final ExecutorService executor = Executors.newSingleThreadExecutor(r -> { Thread t = new Thread(r, "onguard-signalr-poll"); t.setDaemon(true); return t; });
    private volatile String token, connectionId, messageId = "", groupsToken = "";
    private volatile JsonArray subscriptionArgs;
    private volatile boolean subscribed;
    private volatile long invokeCounter;
    private volatile CompletableFuture<JsonElement> pendingInvocation;
    private volatile String pendingInvocationId;

    /** baseHubUrl must end in /signalr (not /signalr/hubs). */
    public LegacySignalRLongPollingClient(String baseHubUrl, String hubName, String bearerToken) {
        this.base = Objects.requireNonNull(HttpUrl.parse(baseHubUrl), "Invalid SignalR base URL");
        if (!"https".equalsIgnoreCase(base.scheme())) throw new IllegalArgumentException("Use HTTPS for authenticated SignalR traffic");
        this.hub = hubName.toLowerCase(Locale.ROOT);
        JsonArray hubs = new JsonArray(); JsonObject item = new JsonObject(); item.addProperty("name", this.hub); hubs.add(item);
        this.connectionData = hubs.toString();
        this.authHeader = bearerToken == null || bearerToken.isBlank() ? null : "Bearer " + bearerToken;
        this.http = new OkHttpClient.Builder().connectTimeout(Duration.ofSeconds(15)).readTimeout(Duration.ofSeconds(90))
                .callTimeout(Duration.ZERO).retryOnConnectionFailure(true).build();
    }

    public BlockingQueue<JsonObject> events() { return events; }
    public void on(String method, Consumer<JsonArray> handler) { handlers.put(method.toLowerCase(Locale.ROOT), handler); }

    /** Subscribes with two arguments as in legacy OnGuard samples: connectionInfo and subscription. */
    public void setSubscription(JsonObject connectionInfo, JsonObject subscription) {
        JsonArray args = new JsonArray(); args.add(connectionInfo); args.add(subscription); subscriptionArgs = args;
    }

    public void start() {
        if (!running.compareAndSet(false, true)) return;
        executor.submit(this::runLoop);
    }

    private void runLoop() {
        int failures = 0;
        while (running.get()) {
            try {
                establish();
                failures = 0;
                pollLoop();
            } catch (Exception ex) {
                if (running.get()) System.err.println("SignalR connection error: " + ex.getMessage());
            } finally {
                subscribed = false;
                CompletableFuture<JsonElement> f = pendingInvocation;
                if (f != null && !f.isDone()) f.completeExceptionally(new IOException("Connection interrupted"));
                pendingInvocation = null; pendingInvocationId = null;
            }
            if (!running.get()) break;
            failures = Math.min(failures + 1, 6);
            try { Thread.sleep(Math.min(30000L, 1000L << failures)); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); break; }
        }
    }

    private void establish() throws Exception {
        JsonObject negotiate = request("negotiate", commonParams(), false, null);
        token = requireString(negotiate, "ConnectionToken");
        connectionId = requireString(negotiate, "ConnectionId");
        messageId = ""; groupsToken = "";
        Map<String,String> params = connectedParams();
        JsonObject connect = request("connect", params, false, null);
        consume(connect);
        JsonObject started = request("start", params, false, null);
        if (!"started".equalsIgnoreCase(optionalString(started, "Response", "")))
            throw new IOException("Unexpected /start response: " + started);
        System.out.println("Connected to SignalR hub " + hub + " connectionId=" + connectionId);
        if (subscriptionArgs != null) {
            // Invoke from this worker: /send can return before its completion is delivered in /poll.
            sendInvocation("CreateSubscription", subscriptionArgs);
            subscribed = true; // request sent; server acceptance must be checked via completion/callback
        }
    }

    private void pollLoop() throws Exception {
        while (running.get()) {
            Map<String,String> params = connectedParams();
            if (!messageId.isEmpty()) params.put("messageId", messageId);
            if (!groupsToken.isEmpty()) params.put("groupsToken", groupsToken);
            JsonObject envelope = request("poll", params, false, null);
            consume(envelope);
            if (envelope.has("D") && envelope.get("D").isJsonPrimitive() && envelope.get("D").getAsBoolean())
                throw new IOException("Server requested disconnect");
        }
    }

    private void consume(JsonObject envelope) {
        if (envelope.has("C") && !envelope.get("C").isJsonNull()) messageId = envelope.get("C").getAsString();
        if (envelope.has("G") && !envelope.get("G").isJsonNull()) groupsToken = envelope.get("G").getAsString();
        JsonArray messages = envelope.has("M") && envelope.get("M").isJsonArray() ? envelope.getAsJsonArray("M") : new JsonArray();
        for (JsonElement element : messages) {
            if (!element.isJsonObject()) continue;
            JsonObject msg = element.getAsJsonObject();
            if (msg.has("I")) {
                String id = msg.get("I").getAsString();
                CompletableFuture<JsonElement> f = pendingInvocation;
                if (f != null && id.equals(pendingInvocationId)) {
                    if (msg.has("E")) f.completeExceptionally(new IOException(msg.get("E").getAsString()));
                    else f.complete(msg.has("R") ? msg.get("R") : JsonNull.INSTANCE);
                    pendingInvocation = null; pendingInvocationId = null;
                }
                continue;
            }
            String method = optionalString(msg, "M", "");
            if (method.isEmpty()) continue;
            JsonArray args = msg.has("A") && msg.get("A").isJsonArray() ? msg.getAsJsonArray("A") : new JsonArray();
            Consumer<JsonArray> handler = handlers.get(method.toLowerCase(Locale.ROOT));
            if (handler != null) {
                try { handler.accept(args); } catch (RuntimeException e) { System.err.println("Handler error: " + e); }
            }
            if ("onBusinessEventReceived".equalsIgnoreCase(method)) {
                JsonObject event = new JsonObject(); event.addProperty("method", method); event.add("args", args.deepCopy());
                if (!events.offer(event)) System.err.println("EVENT QUEUE FULL: event dropped");
            }
        }
    }

    private void sendInvocation(String method, JsonArray args) throws Exception {
        String id = Long.toString(++invokeCounter);
        JsonObject invocation = new JsonObject(); invocation.addProperty("H", hub); invocation.addProperty("M", method);
        invocation.add("A", args); invocation.addProperty("I", id);
        pendingInvocationId = id; pendingInvocation = new CompletableFuture<>();
        Map<String,String> params = connectedParams();
        request("send", params, true, "data=" + encode(invocation.toString()));
        // Completion is normally delivered asynchronously via /poll. Do not block the polling thread.
    }

    private JsonObject request(String action, Map<String,String> params, boolean post, String form) throws IOException {
        HttpUrl.Builder u = Objects.requireNonNull(base.newBuilder().addPathSegment(action));
        params.forEach(u::addQueryParameter);
        Request.Builder b = new Request.Builder().url(u.build()).header("Accept", "application/json")
                .header("User-Agent", "OnGuard-OkHttp-SignalR2/1.0");
        if (authHeader != null) b.header("Authorization", authHeader);
        b.method(post ? "POST" : "GET", post ? RequestBody.create(form == null ? "" : form, FORM) : null);
        try (Response r = http.newCall(b.build()).execute()) {
            String body = r.body() == null ? "" : r.body().string();
            if (!r.isSuccessful()) throw new IOException("HTTP " + r.code() + " from /" + action);
            // SignalR responses may have a JSON anti-hijacking prefix in some deployments.
            if (body.startsWith("{}&&")) body = body.substring(4);
            JsonElement parsed = JsonParser.parseString(body);
            if (!parsed.isJsonObject()) throw new IOException("Expected JSON object from /" + action);
            return parsed.getAsJsonObject();
        }
    }

    private Map<String,String> commonParams() {
        Map<String,String> p = new LinkedHashMap<>(); p.put("clientProtocol", PROTOCOL); p.put("connectionData", connectionData); return p;
    }
    private Map<String,String> connectedParams() {
        Map<String,String> p = commonParams(); p.put("transport", "longPolling"); p.put("connectionToken", token); return p;
    }
    private static String encode(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }
    private static String requireString(JsonObject o, String key) throws IOException {
        if (!o.has(key) || o.get(key).isJsonNull()) throw new IOException("Missing " + key);
        return o.get(key).getAsString();
    }
    private static String optionalString(JsonObject o, String key, String fallback) {
        return o.has(key) && !o.get(key).isJsonNull() ? o.get(key).getAsString() : fallback;
    }
    @Override public void close() {
        running.set(false); executor.shutdownNow();
        http.dispatcher().cancelAll(); http.dispatcher().executorService().shutdown(); http.connectionPool().evictAll();
    }
}

package example.onguard;

import com.google.gson.*;

public class Main {
    public static void main(String[] args) throws Exception {
        String url = required("ONGUARD_SIGNALR_URL"); // e.g. https://host/signalr
        String token = System.getenv("ONGUARD_TOKEN");
        String applicationId = required("ONGUARD_APPLICATION_ID");
        String directoryId = required("ONGUARD_DIRECTORY_ID");
        JsonObject connectionInfo = new JsonObject();
        connectionInfo.addProperty("SessionToken", required("ONGUARD_SESSION_TOKEN"));
        connectionInfo.addProperty("ApplicationId", applicationId);
        connectionInfo.addProperty("DirectoryId", directoryId);
        JsonObject subscription = new JsonObject();
        subscription.addProperty("description", "Niagara event subscription");
        subscription.addProperty("filter", "");
        subscription.addProperty("is_durable", false);
        subscription.addProperty("is_modifysub", false);
        subscription.addProperty("id", 0);
        // IMPORTANT: connectionInfo and subscription JSON above are placeholders.
        // Replace field names/types with those required by the installed OnGuard bridge.
        try (LegacySignalRLongPollingClient client = new LegacySignalRLongPollingClient(url, "Outbound", token)) {
            client.setSubscription(connectionInfo, subscription);
            client.on("onConnectionToMessageBusEstablished", a -> System.out.println("Message bus established"));
            client.on("onConnectionToMessageBusLost", a -> System.err.println("Message bus lost"));
            client.on("onExceptionRaised", a -> System.err.println("Bridge exception: " + a));
            client.on("onManagementEvent", a -> System.out.println("Management event: " + a));
            client.start();
            while (!Thread.currentThread().isInterrupted()) {
                JsonObject event = client.events().take();
                System.out.println("OnGuard event: " + event);
            }
        }
    }
    private static String required(String key) {
        String value = System.getenv(key);
        if (value == null || value.isBlank()) throw new IllegalArgumentException("Missing env var " + key);
        return value;
    }
}

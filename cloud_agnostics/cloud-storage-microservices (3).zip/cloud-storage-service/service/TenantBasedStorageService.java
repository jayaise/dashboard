package com.example.cloudstorage.service;

import com.example.cloudstorage.model.FileMetadata;
import com.example.cloudstorage.model.CloudProviderConfig;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.client.RestTemplate;

import java.util.UUID;

@Service
public class TenantBasedStorageService {

    private final RestTemplate restTemplate;
    private final CloudStorageFactory cloudStorageFactory;

    public TenantBasedStorageService(RestTemplate restTemplate, CloudStorageFactory cloudStorageFactory) {
        this.restTemplate = restTemplate;
        this.cloudStorageFactory = cloudStorageFactory;
    }

    public FileMetadata uploadFile(MultipartFile file, String tenantId) {
        // 1. Get provider config from cloud-provider-service
        CloudProviderConfig config = restTemplate.getForObject(
            "http://cloud-provider-service/api/providers/" + tenantId,
            CloudProviderConfig.class
        );

        // 2. Use factory to create appropriate storage service
        CloudStorageService storageService = cloudStorageFactory.getService(config);

        // 3. Generate unique key and upload file
        String key = UUID.randomUUID() + "-" + file.getOriginalFilename();
        storageService.upload(file, key, config);

        // 4. Return metadata
        return FileMetadata.builder()
                .id(UUID.randomUUID())
                .tenantId(tenantId)
                .filename(file.getOriginalFilename())
                .objectKey(key)
                .provider(config.getProviderType())
                .size(file.getSize())
                .contentType(file.getContentType())
                .uploadedAt(java.time.LocalDateTime.now())
                .build();
    }
}

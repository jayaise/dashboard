package com.example.cloudstorage.service;

import com.example.cloudstorage.model.CloudProviderConfig;
import org.springframework.stereotype.Component;

@Component
public class CloudStorageFactory {

    public CloudStorageService getService(CloudProviderConfig config) {
        return switch (config.getProviderType().toLowerCase()) {
            case "s3" -> new S3StorageServiceImpl(config);
            case "azure" -> new AzureStorageServiceImpl(config);
            case "gcs" -> new GCSStorageServiceImpl(config);
            case "minio" -> new MinioStorageServiceImpl(config);
            default -> throw new IllegalArgumentException("Unsupported provider type: " + config.getProviderType());
        };
    }
}

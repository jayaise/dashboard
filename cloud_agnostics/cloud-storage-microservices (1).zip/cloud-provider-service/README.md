# Cloud Provider Service
Manages cloud provider configurations (S3, Azure, GCS, MinIO).
package com.example.cloudstorage.controller;

import com.example.cloudstorage.service.CloudStorageService;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.UUID;

@Tag(name = "File API", description = "Upload, download, and manage files")
@RestController
@RequestMapping("/api/files")
public class FileController {

    @Autowired
    private CloudStorageService storageService;

    @PostMapping("/upload")
    public ResponseEntity<String> upload(@RequestParam MultipartFile file) {
        String key = UUID.randomUUID() + "-" + file.getOriginalFilename();
        return ResponseEntity.ok(storageService.upload(file, key));
    }

    @GetMapping("/download/{key}")
    public ResponseEntity<byte[]> download(@PathVariable String key) {
        return ResponseEntity.ok(storageService.download(key));
    }

    @DeleteMapping("/{key}")
    public ResponseEntity<Void> delete(@PathVariable String key) {
        storageService.delete(key);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/presigned/{key}")
    public ResponseEntity<String> presigned(@PathVariable String key) {
        return ResponseEntity.ok(storageService.generatePresignedUrl(key));
    }
}

package com.example.cloudstorage.controller;

import com.example.cloudstorage.model.CloudProviderConfig;
import com.example.cloudstorage.service.CloudProviderConfigService;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Tag(name = "Cloud Provider Config API", description = "Manage cloud provider configurations")
@RestController
@RequestMapping("/api/providers")
public class CloudProviderController {

    @Autowired
    private CloudProviderConfigService providerService;

    @GetMapping
    public List<CloudProviderConfig> getAll() {
        return providerService.getAll();
    }

    @GetMapping("/{tenantId}")
    public ResponseEntity<CloudProviderConfig> getByTenant(@PathVariable String tenantId) {
        return ResponseEntity.ok(providerService.getProviderForTenant(tenantId));
    }

    @PostMapping
    public ResponseEntity<CloudProviderConfig> create(@RequestBody CloudProviderConfig config) {
        return ResponseEntity.ok(providerService.save(config));
    }

    @PutMapping
    public ResponseEntity<CloudProviderConfig> update(@RequestBody CloudProviderConfig config) {
        return ResponseEntity.ok(providerService.save(config));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        providerService.delete(id);
        return ResponseEntity.noContent().build();
    }
}

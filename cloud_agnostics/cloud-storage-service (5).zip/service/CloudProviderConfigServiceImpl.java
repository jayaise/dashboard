package com.example.cloudstorage.service;

import com.example.cloudstorage.model.CloudProviderConfig;
import com.example.cloudstorage.repository.CloudProviderConfigRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CloudProviderConfigServiceImpl implements CloudProviderConfigService {

    @Autowired
    private CloudProviderConfigRepository repository;

    @Override
    public CloudProviderConfig getProviderForTenant(String tenantId) {
        return repository.findByTenantId(tenantId)
                .orElseThrow(() -> new RuntimeException("No provider config found for tenant: " + tenantId));
    }

    @Override
    public List<CloudProviderConfig> getAll() {
        return repository.findAll();
    }

    @Override
    public CloudProviderConfig save(CloudProviderConfig config) {
        return repository.save(config);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }
}

package com.example.cloudstorage.service;

import com.azure.storage.blob.*;
import com.azure.storage.blob.models.*;
import com.azure.storage.blob.sas.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.time.OffsetDateTime;

@Service
public class AzureStorageServiceImpl implements CloudStorageService {

    private final BlobContainerClient containerClient;

    public AzureStorageServiceImpl(@Value("${azure.blob.connection-string}") String connectionString,
                                   @Value("${azure.blob.container}") String containerName) {
        BlobServiceClient serviceClient = new BlobServiceClientBuilder()
                .connectionString(connectionString)
                .buildClient();
        this.containerClient = serviceClient.getBlobContainerClient(containerName);
    }

    @Override
    public String upload(MultipartFile file, String path) {
        try {
            BlobClient blobClient = containerClient.getBlobClient(path);
            blobClient.upload(file.getInputStream(), file.getSize(), true);
            return path;
        } catch (IOException e) {
            throw new RuntimeException("Azure upload failed", e);
        }
    }

    @Override
    public byte[] download(String path) {
        BlobClient blobClient = containerClient.getBlobClient(path);
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        blobClient.download(outputStream);
        return outputStream.toByteArray();
    }

    @Override
    public void delete(String path) {
        containerClient.getBlobClient(path).delete();
    }

    @Override
    public String generatePresignedUrl(String path) {
        BlobClient blobClient = containerClient.getBlobClient(path);
        OffsetDateTime expiryTime = OffsetDateTime.now().plusHours(1);
        BlobServiceSasSignatureValues values = new BlobServiceSasSignatureValues(expiryTime, BlobSasPermission.parse("r"));
        return blobClient.getBlobUrl() + "?" + blobClient.generateSas(values);
    }
}

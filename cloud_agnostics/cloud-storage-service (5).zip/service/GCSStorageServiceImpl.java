package com.example.cloudstorage.service;

import com.google.cloud.storage.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

@Service
public class GCSStorageServiceImpl implements CloudStorageService {

    private final Storage storage;

    @Value("${gcp.bucket}")
    private String bucket;

    public GCSStorageServiceImpl() {
        this.storage = StorageOptions.getDefaultInstance().getService();
    }

    @Override
    public String upload(MultipartFile file, String path) {
        try {
            BlobId blobId = BlobId.of(bucket, path);
            BlobInfo blobInfo = BlobInfo.newBuilder(blobId).setContentType(file.getContentType()).build();
            storage.create(blobInfo, file.getBytes());
            return path;
        } catch (IOException e) {
            throw new RuntimeException("GCS upload failed", e);
        }
    }

    @Override
    public byte[] download(String path) {
        Blob blob = storage.get(BlobId.of(bucket, path));
        if (blob == null) throw new RuntimeException("File not found");
        return blob.getContent();
    }

    @Override
    public void delete(String path) {
        storage.delete(BlobId.of(bucket, path));
    }

    @Override
    public String generatePresignedUrl(String path) {
        BlobInfo blobInfo = BlobInfo.newBuilder(bucket, path).build();
        URL url = storage.signUrl(blobInfo, 1, TimeUnit.HOURS);
        return url.toString();
    }
}

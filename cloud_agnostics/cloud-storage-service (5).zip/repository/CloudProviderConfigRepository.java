package com.example.cloudstorage.repository;

import com.example.cloudstorage.model.CloudProviderConfig;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface CloudProviderConfigRepository extends JpaRepository<CloudProviderConfig, Long> {
    Optional<CloudProviderConfig> findByTenantId(String tenantId);
}

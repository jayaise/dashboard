package com.example.cloudstorage.config;

import com.example.cloudstorage.service.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class StorageConfig {

    @Value("${storage.provider}")
    private String provider;

    private final S3StorageServiceImpl s3 = null;
    private final AzureStorageServiceImpl azure = null;
    private final GCSStorageServiceImpl gcs = null;
    private final MinioStorageServiceImpl minio = null;

    @Bean
    public CloudStorageService cloudStorageService() {
        return switch (provider.toLowerCase()) {
            case "s3" -> s3;
            case "azure" -> azure;
            case "gcs" -> gcs;
            case "minio" -> minio;
            default -> throw new IllegalArgumentException("Unsupported storage provider: " + provider);
        };
    }
}

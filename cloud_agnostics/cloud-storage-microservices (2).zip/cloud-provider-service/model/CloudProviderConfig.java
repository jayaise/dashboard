package com.example.cloudstorage.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CloudProviderConfig {
    @Id
    private UUID id;

    private String tenantId;
    private String providerType;
    private String accessKey;
    private String secretKey;
    private String connectionString;
    private String bucketName;
    private String region;
    private String endpointUrl;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}

package com.example.cloudstorage.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class FileMetadata {
    @Id
    private UUID id;

    private String tenantId;
    private String filename;
    private String objectKey;
    private String provider;
    private Long size;
    private String contentType;
    private LocalDateTime uploadedAt;
}

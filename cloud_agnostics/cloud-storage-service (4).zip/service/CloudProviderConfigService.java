package com.example.cloudstorage.service;

import com.example.cloudstorage.model.CloudProviderConfig;

import java.util.List;

public interface CloudProviderConfigService {
    CloudProviderConfig getProviderForTenant(String tenantId);
    List<CloudProviderConfig> getAll();
    CloudProviderConfig save(CloudProviderConfig config);
    void delete(Long id);
}

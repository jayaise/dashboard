package com.example.cloudstorage.service;

import org.springframework.web.multipart.MultipartFile;

public interface CloudStorageService {
    String upload(MultipartFile file, String path);
    byte[] download(String path);
    void delete(String path);
    String generatePresignedUrl(String path);
}

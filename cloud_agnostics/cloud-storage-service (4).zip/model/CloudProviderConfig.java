package com.example.cloudstorage.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CloudProviderConfig {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String tenantId;
    private String providerType; // s3, azure, gcs, minio
    private String accessKey;
    private String secretKey;
    private String connectionString;
    private String bucketName;
}

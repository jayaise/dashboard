package com.example.cloudstorage.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.*;

import java.io.IOException;

@Service
public class S3StorageServiceImpl implements CloudStorageService {

    private final S3Client s3Client;

    @Value("${cloud.aws.s3.bucket}")
    private String bucket;

    public S3StorageServiceImpl(
        @Value("${cloud.aws.credentials.access-key}") String accessKey,
        @Value("${cloud.aws.credentials.secret-key}") String secretKey,
        @Value("${cloud.aws.region.static}") String region
    ) {
        this.s3Client = S3Client.builder()
                .region(Region.of(region))
                .credentialsProvider(StaticCredentialsProvider.create(
                        AwsBasicCredentials.create(accessKey, secretKey)))
                .build();
    }

    public String upload(MultipartFile file, String path) {
        try {
            PutObjectRequest putReq = PutObjectRequest.builder()
                    .bucket(bucket)
                    .key(path)
                    .contentType(file.getContentType())
                    .build();
            s3Client.putObject(putReq, software.amazon.awssdk.core.sync.RequestBody.fromBytes(file.getBytes()));
            return path;
        } catch (IOException e) {
            throw new RuntimeException("S3 upload failed", e);
        }
    }

    public byte[] download(String path) {
        GetObjectRequest getReq = GetObjectRequest.builder()
                .bucket(bucket)
                .key(path)
                .build();
        return s3Client.getObject(getReq).readAllBytes();
    }

    public void delete(String path) {
        s3Client.deleteObject(DeleteObjectRequest.builder()
                .bucket(bucket)
                .key(path)
                .build());
    }

    public String generatePresignedUrl(String path) {
        return s3Client.utilities().getUrl(builder -> builder
                .bucket(bucket)
                .key(path)).toString();
    }
}

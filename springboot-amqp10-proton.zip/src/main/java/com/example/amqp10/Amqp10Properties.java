package com.example.amqp10;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "amqp10")
public class Amqp10Properties {
  public String host;
  public int port;
  public String username;
  public String password;
  public String address;
  public String clientId;
}

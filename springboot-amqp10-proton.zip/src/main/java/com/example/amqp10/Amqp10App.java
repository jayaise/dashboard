package com.example.amqp10;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

@SpringBootApplication
@EnableConfigurationProperties(Amqp10Properties.class)
public class Amqp10App {
  public static void main(String[] args) {
    SpringApplication.run(Amqp10App.class, args);
  }
}

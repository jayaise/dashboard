package com.example.amqp10;

import org.apache.qpid.protonj2.client.Client;
import org.apache.qpid.protonj2.client.ClientOptions;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ProtonClientConfig {

  @Bean(destroyMethod = "close")
  public Client protonClient(Amqp10Properties props) {
    return Client.create(new ClientOptions().id(props.clientId));
  }
}

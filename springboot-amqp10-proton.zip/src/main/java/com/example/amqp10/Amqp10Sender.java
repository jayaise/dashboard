package com.example.amqp10;

import org.apache.qpid.protonj2.client.*;
import org.springframework.stereotype.Service;
import java.time.Duration;
import java.util.UUID;

@Service
public class Amqp10Sender {

  private final Client client;
  private final Amqp10Properties props;

  public Amqp10Sender(Client client, Amqp10Properties props) {
    this.client = client;
    this.props = props;
  }

  public void send(String payload) {
    try (Connection connection = client.connect(
            props.host + ":" + props.port,
            new ConnectionOptions().user(props.username).password(props.password));
         Sender sender = connection.openSender(props.address)) {

      Message<String> msg = Message.create(payload);
      msg.id(UUID.randomUUID().toString());

      Tracker tracker = sender.send(msg);
      tracker.awaitSettledOrThrow(Duration.ofSeconds(10));
    }
  }
}

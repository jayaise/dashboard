package com.example.amqp10;

import org.apache.qpid.protonj2.client.*;
import org.springframework.stereotype.Component;
import jakarta.annotation.PostConstruct;
import java.time.Duration;

@Component
public class Amqp10Receiver {

  private final Client client;
  private final Amqp10Properties props;

  public Amqp10Receiver(Client client, Amqp10Properties props) {
    this.client = client;
    this.props = props;
  }

  @PostConstruct
  public void start() {
    new Thread(this::listen, "amqp10-receiver").start();
  }

  private void listen() {
    try (Connection connection = client.connect(
            props.host + ":" + props.port,
            new ConnectionOptions().user(props.username).password(props.password));
         Receiver receiver = connection.openReceiver(props.address)) {

      while (true) {
        Delivery delivery = receiver.receive(Duration.ofSeconds(5));
        if (delivery != null) {
          System.out.println("Received: " + delivery.message().body());
          delivery.accept();
          delivery.settle();
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}

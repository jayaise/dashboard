import React, { useMemo, useState } from 'react';

export interface ColumnDefinition {
  key: string;
  label: string;
}

export interface TableWidgetProps {
  data: any[];
  columns: ColumnDefinition[];
  showSearch?: boolean;
  filterableFields?: string[];
  sortable?: boolean;
  pagination?: boolean;
  pageSize?: number;
}

export const TableWidget: React.FC<TableWidgetProps> = ({
  data,
  columns,
  showSearch = false,
  filterableFields = [],
  sortable = false,
  pagination = false,
  pageSize = 10,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);

  const filteredData = useMemo(() => {
    if (!showSearch || !searchTerm) return data;
    return data.filter(row =>
      filterableFields.some(field =>
        String(row[field]).toLowerCase().includes(searchTerm.toLowerCase())
      )
    );
  }, [data, searchTerm, filterableFields]);

  const sortedData = useMemo(() => {
    if (!sortable) return filteredData;
    return [...filteredData].sort((a, b) => {
      const aVal = a[columns[0].key];
      const bVal = b[columns[0].key];
      return aVal > bVal ? 1 : -1;
    });
  }, [filteredData, sortable, columns]);

  const paginatedData = useMemo(() => {
    if (!pagination) return sortedData;
    const start = (currentPage - 1) * pageSize;
    return sortedData.slice(start, start + pageSize);
  }, [sortedData, currentPage, pageSize]);

  return (
    <div>
      {showSearch && (
        <input
          placeholder="Search..."
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
        />
      )}
      <table>
        <thead>
          <tr>
            {columns.map(col => <th key={col.key}>{col.label}</th>)}
          </tr>
        </thead>
        <tbody>
          {paginatedData.map((row, idx) => (
            <tr key={idx}>
              {columns.map(col => <td key={col.key}>{row[col.key]}</td>)}
            </tr>
          ))}
        </tbody>
      </table>
      {pagination && (
        <div>
          Page:
          {[...Array(Math.ceil(sortedData.length / pageSize)).keys()].map(p => (
            <button key={p} onClick={() => setCurrentPage(p + 1)}>{p + 1}</button>
          ))}
        </div>
      )}
    </div>
  );
};

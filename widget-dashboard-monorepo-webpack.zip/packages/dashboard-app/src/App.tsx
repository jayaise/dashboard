import React from 'react';
import { WidgetRenderer } from './components/WidgetRenderer';

const data = [
  { id: 1, name: 'John', role: 'Admin' },
  { id: 2, name: 'Alice', role: 'User' },
  { id: 3, name: 'Bob', role: 'Guest' },
];

const columns = [
  { key: 'id', label: 'ID' },
  { key: 'name', label: 'Name' },
  { key: 'role', label: 'Role' },
];

const App: React.FC = () => {
  return (
    <div style={{ padding: '2rem' }}>
      <h1>Dashboard</h1>
      <WidgetRenderer
        type="table"
        props={{
          data,
          columns,
          showSearch: true,
          filterableFields: ['name', 'role'],
          sortable: true,
          pagination: true,
          pageSize: 2,
        }}
      />
    </div>
  );
};

export default App;

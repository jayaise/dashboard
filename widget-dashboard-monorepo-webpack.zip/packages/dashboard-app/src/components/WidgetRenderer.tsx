import React from 'react';
import { TableWidget, TableWidgetProps } from 'widget-library';

type WidgetRendererProps = {
  type: string;
  props: TableWidgetProps;
};

export const WidgetRenderer: React.FC<WidgetRendererProps> = ({ type, props }) => {
  switch (type) {
    case 'table':
      return <TableWidget {...props} />;
    default:
      return <div>Unknown widget type</div>;
  }
};

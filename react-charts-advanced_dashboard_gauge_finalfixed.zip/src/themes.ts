export const lightTheme = {
  backgroundColor: '#ffffff',
  textColor: '#000000'
};

export const darkTheme = {
  backgroundColor: '#1f1f1f',
  textColor: '#ffffff'
};
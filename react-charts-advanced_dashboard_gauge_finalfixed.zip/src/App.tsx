import React from 'react';
import HighchartsPie from './charts/HighchartsPie';
import EchartsPie from './charts/EchartsPie';
import HighchartsBarAdvanced from './charts/HighchartsBarAdvanced';
import EchartsBarAdvanced from './charts/EchartsBarAdvanced';
import HighchartsGauge from './charts/HighchartsGauge';
import EchartsGauge from './charts/EchartsGauge';
import HighchartsCombo from './charts/HighchartsCombo';
import EchartsCombo from './charts/EchartsCombo';
import HighchartsDrilldown from './charts/HighchartsDrilldown';
import EchartsDrilldown from './charts/EchartsDrilldown';
import { ThemeProvider, useTheme } from './contexts/ThemeContext';

const ThemeToggle: React.FC = () => {
  const { toggleTheme } = useTheme();
  return <button onClick={toggleTheme}>Toggle Theme</button>;
};

const ChartApp: React.FC = () => {
  const { theme } = useTheme();

  return (
    <div style={{ padding: 20, background: theme.backgroundColor, color: theme.textColor, minHeight: '100vh' }}>
      <h2>Slim Chart Dashboard</h2>
      <ThemeToggle />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(500px, 1fr))', gap: '20px', marginTop: '20px' }}>
        <div>
          <h3>Highcharts Bar</h3>
          <HighchartsBarAdvanced />
        </div>
        <div>
          <h3>ECharts Bar</h3>
          <EchartsBarAdvanced />
        </div>
        <div>
          <h3>Highcharts Gauge</h3>
          <HighchartsGauge />
        </div>
        <div>
          <h3>ECharts Gauge</h3>
          <EchartsGauge />
        </div>
      </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(500px, 1fr))', gap: '20px', marginTop: '20px' }}>
        <div>
          <h3>Highcharts Pie</h3>
          <HighchartsPie />
        </div>
        <div>
          <h3>ECharts Pie</h3>
          <EchartsPie />
        </div>
        <div>
          <h3>Highcharts Combination</h3>
          <HighchartsCombo />
        </div>
        <div>
          <h3>ECharts Combination</h3>
          <EchartsCombo />
        </div>
        <div>
          <h3>Highcharts Drilldown</h3>
          <HighchartsDrilldown />
        </div>
        <div>
          <h3>ECharts Drilldown</h3>
          <EchartsDrilldown />
        </div>
      </div>
    </div>
  );
};

const App: React.FC = () => (
  <ThemeProvider>
    <ChartApp />
  </ThemeProvider>
);

export default App;
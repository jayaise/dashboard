import React from 'react';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import { ResizableBox } from 'react-resizable';
import 'react-resizable/css/styles.css';

const HighchartsCombo: React.FC = () => {
  const options: Highcharts.Options = {
    title: { text: 'Highcharts Combination Chart' },
    xAxis: { categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May'] },
    yAxis: [{ title: { text: 'Rainfall' } }, { title: { text: 'Temperature' }, opposite: true }],
    series: [
      { name: 'Rainfall', type: 'column', data: [49.9, 71.5, 106.4, 129.2, 144.0] },
      { name: 'Temperature', type: 'spline', yAxis: 1, data: [7.0, 6.9, 9.5, 14.5, 18.2] }
    ]
  };

  return (
    <ResizableBox width={600} height={300} minConstraints={[300, 200]} maxConstraints={[1000, 600]} resizeHandles={['se']}>
      <div style={{ width: '100%', height: '100%' }}>
        <HighchartsReact highcharts={Highcharts} options={options} />
      </div>
    </ResizableBox>
  );
};

export default HighchartsCombo;
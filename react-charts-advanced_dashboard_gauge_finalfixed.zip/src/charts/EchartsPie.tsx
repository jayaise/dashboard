import React from 'react';
import ReactECharts from 'echarts-for-react';
import { ResizableBox } from 'react-resizable';
import 'react-resizable/css/styles.css';

const EchartsPie: React.FC = () => {
  const option = {
    title: {
      text: 'ECharts Pie Chart',
      subtext: 'Browser Usage',
      left: 'center'
    },
    tooltip: { trigger: 'item' },
    legend: { orient: 'horizontal', bottom: 0 },
    series: [
      {
        name: 'Share',
        type: 'pie',
        radius: '50%',
        data: [
          { value: 1048, name: 'Chrome' },
          { value: 735, name: 'Firefox' },
          { value: 580, name: 'Safari' },
          { value: 484, name: 'Edge' },
          { value: 300, name: 'Others' }
        ],
        emphasis: {
          itemStyle: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowColor: 'rgba(0, 0, 0, 0.5)'
          }
        }
      }
    ]
  };

  return (
    <ResizableBox width={600} height={300} minConstraints={[300, 200]} maxConstraints={[1000, 600]} resizeHandles={['se']}>
      <div style={{ width: '100%', height: '100%' }}>
        <ReactECharts option={option} style={{ height: '100%', width: '100%' }} />
      </div>
    </ResizableBox>
  );
};

export default EchartsPie;
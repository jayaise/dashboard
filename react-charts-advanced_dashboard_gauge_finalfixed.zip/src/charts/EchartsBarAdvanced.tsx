import React from 'react';
import ReactECharts from 'echarts-for-react';
import { ResizableBox } from 'react-resizable';
import 'react-resizable/css/styles.css';

const EchartsBarAdvanced: React.FC = () => {
  const option = {
    title: { text: 'ECharts Bar Chart' },
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
    legend: { bottom: 0 },
    xAxis: { type: 'category', data: ['Apples', 'Bananas', 'Oranges'] },
    yAxis: { type: 'value' },
    series: [
      { name: 'John', type: 'bar', data: [5, 3, 4] },
      { name: 'Jane', type: 'bar', data: [2, 2, 3] },
      { name: 'Joe', type: 'bar', data: [3, 4, 4] }
    ]
  };

  return (
    <ResizableBox width={600} height={300} minConstraints={[300, 200]} maxConstraints={[1000, 600]} resizeHandles={['se']}>
      <div style={{ width: '100%', height: '100%' }}>
        <ReactECharts option={option} style={{ height: '100%', width: '100%' }} />
      </div>
    </ResizableBox>
  );
};

export default EchartsBarAdvanced;
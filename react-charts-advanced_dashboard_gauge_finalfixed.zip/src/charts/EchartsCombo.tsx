import React from 'react';
import ReactECharts from 'echarts-for-react';
import { ResizableBox } from 'react-resizable';
import 'react-resizable/css/styles.css';

const EchartsCombo: React.FC = () => {
  const option = {
    title: { text: 'ECharts Combination Chart (Bright Theme)' },
    tooltip: { trigger: 'axis' },
    legend: {
      data: ['Evaporation', 'Precipitation', 'Temperature'],
      bottom: 0
    },
    color: ['#7cb5ec', '#434348', '#90ed7d'],
    xAxis: {
      type: 'category',
      data: ['Jan', 'Feb', 'Mar', 'Apr', 'May']
    },
    yAxis: [
      { type: 'value', name: 'Water (ml)' },
      { type: 'value', name: 'Temperature (°C)' }
    ],
    series: [
      {
        name: 'Evaporation',
        type: 'bar',
        data: [2.0, 4.9, 7.0, 23.2, 25.6],
        barWidth: 20
      },
      {
        name: 'Precipitation',
        type: 'bar',
        data: [2.6, 5.9, 9.0, 26.4, 28.7],
        barWidth: 20
      },
      {
        name: 'Temperature',
        type: 'line',
        yAxisIndex: 1,
        data: [2.0, 2.2, 3.3, 4.5, 6.3]
      }
    ]
  };

  return (
    <ResizableBox
      width={600}
      height={300}
      minConstraints={[300, 200]}
      maxConstraints={[1000, 600]}
      resizeHandles={['se']}
    >
      <div style={{ width: '100%', height: '100%' }}>
        <ReactECharts option={option} style={{ height: '100%', width: '100%' }} />
      </div>
    </ResizableBox>
  );
};

export default EchartsCombo;
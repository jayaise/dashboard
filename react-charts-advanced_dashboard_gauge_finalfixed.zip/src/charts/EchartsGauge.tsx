import React from 'react';
import ReactECharts from 'echarts-for-react';
import { ResizableBox } from 'react-resizable';
import 'react-resizable/css/styles.css';

const EchartsGauge: React.FC = () => {
  const option = {
    title: {
      text: 'ECharts Speedometer Gauge'
    },
    tooltip: {
      formatter: '{a} <br/>{b} : {c} km/h'
    },
    series: [
      {
        name: 'Speed',
        type: 'gauge',
        startAngle: 180,
        endAngle: 0,
        min: 0,
        max: 100,
        center: ['50%', '75%'],
        radius: '90%',
        splitNumber: 5,
        axisLine: {
          lineStyle: {
            width: 30,
            color: [
              [0.3, '#55BF3B'],
              [0.7, '#DDDF0D'],
              [1, '#DF5353']
            ]
          }
        },
        pointer: {
          show: true,
          length: '60%',
          width: 5
        },
        axisTick: {
          show: false
        },
        splitLine: {
          length: 15,
          lineStyle: {
            width: 1,
            color: '#999'
          }
        },
        axisLabel: {
          distance: -35,
          color: '#999',
          fontSize: 12
        },
        title: {
          offsetCenter: [0, '-30%'],
          fontSize: 14
        },
        detail: {
          valueAnimation: true,
          fontSize: 20,
          offsetCenter: [0, '-10%'],
          formatter: '{value} km/h',
          color: 'auto'
        },
        data: [{ value: 70, name: 'Speed' }]
      }
    ]
  };

  return (
    <ResizableBox
      width={600}
      height={300}
      minConstraints={[300, 200]}
      maxConstraints={[1000, 600]}
      resizeHandles={['se']}
    >
      <div style={{ width: '100%', height: '100%' }}>
        <ReactECharts option={option} style={{ height: '100%', width: '100%' }} />
      </div>
    </ResizableBox>
  );
};

export default EchartsGauge;
import React, { useState } from 'react';
import ReactECharts from 'echarts-for-react';
import { ResizableBox } from 'react-resizable';
import 'react-resizable/css/styles.css';

const EchartsDrilldown: React.FC = () => {
  const [drillData, setDrillData] = useState<any | null>(null);

  const baseOption = {
    title: { text: 'ECharts Drilldown (Bright Theme)' },
    tooltip: {},
    legend: { bottom: 0 },
    color: ['#7cb5ec', '#434348', '#90ed7d', '#f7a35c'],
    xAxis: { type: 'category', data: ['Engineering', 'Sales'] },
    yAxis: { type: 'value' },
    series: [
      {
        type: 'bar',
        data: [
          { value: 60, name: 'Engineering' },
          { value: 40, name: 'Sales' }
        ],
        barWidth: 40
      }
    ]
  };

  const onClick = (params: any) => {
    if (params.name === 'Engineering') {
      setDrillData({
        title: { text: 'Engineering Breakdown' },
        xAxis: { type: 'category', data: ['Frontend', 'Backend', 'DevOps'] },
        yAxis: { type: 'value' },
        series: [{
          type: 'bar',
          data: [25, 20, 15],
          barWidth: 30,
          itemStyle: { color: '#7cb5ec' }
        }]
      });
    } else if (params.name === 'Sales') {
      setDrillData({
        title: { text: 'Sales Breakdown' },
        xAxis: { type: 'category', data: ['Domestic', 'International'] },
        yAxis: { type: 'value' },
        series: [{
          type: 'bar',
          data: [20, 20],
          barWidth: 30,
          itemStyle: { color: '#434348' }
        }]
      });
    }
  };

  return (
    <ResizableBox width={600} height={300} minConstraints={[300, 200]} maxConstraints={[1000, 600]} resizeHandles={['se']}>
      <div style={{ width: '100%', height: '100%' }}>
        <button onClick={() => setDrillData(null)}>Back</button>
        <ReactECharts
          option={drillData || baseOption}
          style={{ height: '100%', width: '100%' }}
          onEvents={{ click: onClick }}
        />
      </div>
    </ResizableBox>
  );
};

export default EchartsDrilldown;
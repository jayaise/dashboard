import React from 'react';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import { ResizableBox } from 'react-resizable';
import 'react-resizable/css/styles.css';

const HighchartsPie: React.FC = () => {
  const options: Highcharts.Options = {
    chart: { type: 'pie' },
    title: { text: 'Highcharts Pie Chart' },
    series: [{
      name: 'Browsers',
      type: 'pie',
      data: [
        { name: 'Chrome', y: 61.41 },
        { name: 'Edge', y: 11.84 },
        { name: 'Firefox', y: 10.85 },
        { name: 'Safari', y: 4.67 },
        { name: 'Others', y: 10.23 }
      ]
    }]
  };

  return (
    <ResizableBox width={600} height={300} minConstraints={[300, 200]} maxConstraints={[1000, 600]} resizeHandles={['se']}>
      <div style={{ width: '100%', height: '100%' }}>
        <HighchartsReact highcharts={Highcharts} options={options} />
      </div>
    </ResizableBox>
  );
};

export default HighchartsPie;
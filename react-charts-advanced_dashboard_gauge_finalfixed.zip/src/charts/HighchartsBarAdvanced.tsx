import React from 'react';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import { ResizableBox } from 'react-resizable';
import 'react-resizable/css/styles.css';

const HighchartsBarAdvanced: React.FC = () => {
  const options: Highcharts.Options = {
    chart: { type: 'column' },
    title: { text: 'Highcharts Bar Chart' },
    xAxis: { categories: ['Apples', 'Bananas', 'Oranges'], crosshair: true },
    yAxis: { min: 0, title: { text: 'Quantity' } },
    series: [
      { name: 'John', type: 'column', data: [5, 3, 4] },
      { name: 'Jane', type: 'column', data: [2, 2, 3] },
      { name: 'Joe', type: 'column', data: [3, 4, 4] }
    ]
  };

  return (
    <ResizableBox width={600} height={300} minConstraints={[300, 200]} maxConstraints={[1000, 600]} resizeHandles={['se']}>
      <div style={{ width: '100%', height: '100%' }}>
        <HighchartsReact highcharts={Highcharts} options={options} />
      </div>
    </ResizableBox>
  );
};

export default HighchartsBarAdvanced;
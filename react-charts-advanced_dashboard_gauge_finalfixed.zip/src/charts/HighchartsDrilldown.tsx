import React from 'react';
import Highcharts from 'highcharts';
import drilldown from 'highcharts/modules/drilldown';
import HighchartsReact from 'highcharts-react-official';
import { ResizableBox } from 'react-resizable';
import 'react-resizable/css/styles.css';

drilldown(Highcharts);

const HighchartsDrilldown: React.FC = () => {
  const options: Highcharts.Options = {
    chart: { type: 'column' },
    title: { text: 'Highcharts Drilldown' },
    xAxis: { type: 'category' },
    legend: { enabled: false },
    plotOptions: {
      series: {
        borderWidth: 0,
        dataLabels: { enabled: true, format: '{point.y:.1f}%' }
      }
    },
    series: [{
      name: 'Browsers',
      type: 'column',
      colorByPoint: true,
      data: [
        { name: 'Chrome', y: 62.74, drilldown: 'Chrome' },
        { name: 'Firefox', y: 10.57, drilldown: 'Firefox' },
        { name: 'Edge', y: 7.23, drilldown: 'Edge' }
      ]
    }],
    drilldown: {
      series: [
        {
          name: 'Chrome',
          id: 'Chrome',
          data: [['v65.0', 0.1], ['v64.0', 1.3]]
        },
        {
          name: 'Firefox',
          id: 'Firefox',
          data: [['v58.0', 1.02], ['v57.0', 7.36]]
        }
      ]
    }
  };

  return (
    <ResizableBox width={600} height={300} minConstraints={[300, 200]} maxConstraints={[1000, 600]} resizeHandles={['se']}>
      <div style={{ width: '100%', height: '100%' }}>
        <HighchartsReact highcharts={Highcharts} options={options} />
      </div>
    </ResizableBox>
  );
};

export default HighchartsDrilldown;
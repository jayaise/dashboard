import React, { useState } from 'react';

interface Tab {
  label: string;
  content: JSX.Element;
}

interface DashboardLayoutProps {
  tabs: Tab[];
}

const DashboardLayout: React.FC<DashboardLayoutProps> = ({ tabs }) => {
  const [activeTab, setActiveTab] = useState(0);

  return (
    <div style={{ marginTop: 20 }}>
      <div style={{ display: 'flex', gap: 10, marginBottom: 10 }}>
        {tabs.map((tab, index) => (
          <button
            key={index}
            style={{
              padding: '6px 12px',
              background: activeTab === index ? '#007bff' : '#ccc',
              color: activeTab === index ? '#fff' : '#000',
              border: 'none',
              cursor: 'pointer'
            }}
            onClick={() => setActiveTab(index)}
          >
            {tab.label}
          </button>
        ))}
      </div>
      <div style={{ padding: 10, background: '#f9f9f9', borderRadius: 8 }}>
        {tabs[activeTab].content}
      </div>
    </div>
  );
};

export default DashboardLayout;
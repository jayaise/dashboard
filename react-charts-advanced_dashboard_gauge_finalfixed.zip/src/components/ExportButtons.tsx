import React from 'react';

interface ExportButtonsProps {
  chartRef: React.RefObject<any>;
}

const ExportButtons: React.FC<ExportButtonsProps> = ({ chartRef }) => {
  const handleExport = (type: 'png' | 'pdf') => {
    if (chartRef.current) {
      const echartsInstance = chartRef.current.getEchartsInstance();
      const dataUrl = echartsInstance.getDataURL({
        type: type === 'pdf' ? 'png' : type,
        pixelRatio: 2,
        backgroundColor: '#fff'
      });

      const link = document.createElement('a');
      link.href = dataUrl;
      link.download = `chart-export.${type}`;
      link.click();
    }
  };

  return (
    <div style={{ marginBottom: 10 }}>
      <button onClick={() => handleExport('png')}>Export PNG</button>
      <button onClick={() => handleExport('pdf')}>Export PDF</button>
    </div>
  );
};

export default ExportButtons;
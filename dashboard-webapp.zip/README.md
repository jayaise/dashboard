# Dashboard Webapp
Main React dashboard app using widget library.
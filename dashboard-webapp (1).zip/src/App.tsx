
import { useState } from 'react';
import { WidgetContainer, widgetTemplates, WidgetConfigurator } from 'widget-library';
import '../style.css';

function App() {
  const [selectedTemplate, setSelectedTemplate] = useState(widgetTemplates[0]);
  const [widgetConfig, setWidgetConfig] = useState(selectedTemplate.config);

  return (
    <div className="p-6 space-y-6">
      <h1 className="text-2xl font-bold">ThingsBoard React Dashboard</h1>

      <select
        className="border rounded p-2"
        onChange={(e) => {
          const template = widgetTemplates.find(t => t.type === e.target.value);
          if (template) {
            setSelectedTemplate(template);
            setWidgetConfig(template.config);
          }
        }}
        value={selectedTemplate.type}
      >
        {widgetTemplates.map(t => (
          <option key={t.type} value={t.type}>{t.name}</option>
        ))}
      </select>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <WidgetContainer id="demo" config={widgetConfig} />
        <WidgetConfigurator config={widgetConfig} onChange={setWidgetConfig} />
      </div>
    </div>
  );
}

export default App;

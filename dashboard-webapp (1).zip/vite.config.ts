
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      'widget-library': path.resolve(__dirname, '../widget-library/src')
    }
  }
});
